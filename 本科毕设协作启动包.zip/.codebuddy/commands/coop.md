---
description: 同步本科毕设当前任务并继续工作
argument-hint: "[当前任务或问题]"
---
先读取 C:\Users\myby\Desktop\codex\design\AGENTS.md，再按 shared/protocol.md 处理本会话身份、同步和收据，tool 为 workbuddy。
已存在会话身份就复用；新会话先运行公共程序的 session 操作并保留返回值。同步后实际读完才 ack；上下文不可靠时使用 recover。
接上后直接分析或继续已授权工作，不停在“我读完了”。本轮进展按协议发布，确实无变化则登记 noop。
当前用户关注：$ARGUMENTS
