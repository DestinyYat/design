---
alwaysApply: true
---
遵循 C:\Users\myby\Desktop\codex\design\AGENTS.md 及其指向的 shared/protocol.md；工具标识为 workbuddy。
每次处理用户消息前按协议执行公共同步操作。没有原生会话标识时仅创建一次 coop session 并在本会话复用；不与其他会话共用标识。
关键进展当轮发布；桌面 hook 尚未验收，不能假定其已自动同步。论文/办公任务同样使用上述物理项目目录。
