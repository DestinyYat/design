DeepSeek Harness 本机版本：0.2.1-rc.5；已核对桌面运行包的版本和 agent 生命周期事件。
基础入口：项目根 AGENTS.md。按 shared/protocol.md 使用 tool=deepseekharness，先建立本会话身份，每轮同步、当轮发布；这是规则驱动，尚未声称原生自动 hook 已触发。
原生插件接入尚未启用：本机插件加载配置与请求消息插入的完整契约未完成真实客户端验收。不得仅凭网上 master 分支事件名写入活跃插件配置。
后续接入点：agent/pre-step 同步；agent/turn-stopping 校验发布；agent/created 的 startup/resume/clear/compact 恢复。需先固定安装版本并在隔离配置验证，不改用户全局配置。
官方来源：https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/subsystems/core.md
官方指令加载：https://github.com/deepseek-ai/deepseek-harness/blob/master/packages/context/agent-instructions/README.md
