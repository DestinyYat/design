---
alwaysApply: true
---
遵循本项目根目录 AGENTS.md 及其指向的 shared/protocol.md；工具标识为 trae。
项目记录根目录为 C:\Users\myby\Desktop\codex\design。每次处理用户消息前同步，关键进展当轮发布；无 hook 时按公共协议的命令入口操作。
