# 本科毕设协作入口

遵循 `shared/protocol.md`；操作方式见 `shared/QUICKSTART.md`，仅部署或修复时读 `shared/IMPLEMENTATION.md`。
开始处理每条用户消息前，先同步当前任务；优先使用 hook 给出的会话身份和同步包。
没有 hook 时运行 `python tools/coop/coop.py session --tool <codex|trae|workbuddy|deepseekharness>`，在本会话保留返回的 session；随后按 QUICKSTART 调用 sync。
新会话或上下文不可靠时恢复当前任务；已有会话只读增量，确认实际收到同步包后 ack。不得通读全部历史或全部交接卡。
出现重要进展、理由、否决、用户裁决或运行结果时，在本轮结束前 publish；无变化提交 noop receipt。交接卡首行写接给谁、做什么，最多12行。
重要运行必须通过公共 run 操作在启动前保存实际命令、代码与输入；候选成果引用原始事件和证据，用户裁决后收录。
只写本会话记录；公共视图由程序生成。同文件并行修改先协调，不以最后写入者为准。
协作设施初始任务为 `T-START`；毕设题目、方向和完成度以用户后续提供的真实材料为准，当前均未确认。
父目录要求的详细操作审计写入 `../audit/design/<独立会话>/`，仅在审计时按需读取，不自动注入协作上下文；只记录公开可核查的依据，不记录内部思维链。
