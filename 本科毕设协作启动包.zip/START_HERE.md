本科毕设协作入口

四个工具都使用 C:\Users\myby\Desktop\codex\design 作为实际工作目录。
在工具里新建本项目会话，发送：读取 AGENTS.md，接上毕设当前任务，并按我的下一条要求开始工作。
第一次具体研究任务尚未指定；agent 应按用户要求阅读必要毕设材料，再建立相应任务标识。
工具应先同步再回答，关键进展当轮发布；无需用户另写交接总结。
日常只读 AGENTS.md、shared/protocol.md 和同步返回的限额内容。
部署或修复时，把 shared/IMPLEMENTATION.md 发给任意具备本地读写及命令能力的 agent。
工具适配与待验收项见 shared/SETUP_REPORT.md；配置文件存在不等于客户端已经实际触发。
