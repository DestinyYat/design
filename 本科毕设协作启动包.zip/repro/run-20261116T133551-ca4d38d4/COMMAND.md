实际命令参数（JSON数组，重放时按数组执行，不进行shell拼接）：
["D:\\E-CLASS_APP\\py310\\python.exe", "-m", "unittest", "discover", "-s", "tests", "-v"]
工作目录：C:\Users\myby\Desktop\codex\design
输入和代码见 snapshot/ 与 manifest.json；原始路径失效时需先恢复快照并核对依赖。
