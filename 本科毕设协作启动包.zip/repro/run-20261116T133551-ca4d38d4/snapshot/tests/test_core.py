"""Behavior tests for bounded, acknowledged, multi-writer collaboration records."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

CORE_DIR = Path(__file__).resolve().parents[1] / "tools" / "coop"
sys.path.insert(0, str(CORE_DIR))
from core import Store, estimated_tokens


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="coop-core-test-")
        self.root = Path(self.temporary.name)
        self.store = Store(self.root)
        self.store.ensure_initialized()

    def tearDown(self):
        self.temporary.cleanup()

    def publish(self, number=1, tool="trae", session="writer", task="T-1", **extra):
        return self.store.publish(tool, session, task, {"kind": "finding", "summary": f"发现 {number}", "why": "实际证据支持此判断", **extra})

    def drain(self, tool="codex", session="reader", task="T-1", budget=None, max_pages=100):
        texts, packets = [], []
        for _ in range(max_pages):
            packet = self.store.sync(tool, session, task, budget=budget)
            texts.append(packet["text"])
            packets.append(packet)
            if packet["packet_id"]:
                self.store.ack(tool, session, packet["packet_id"])
            if not packet["has_more"]:
                return "\n".join(texts), packets
        self.fail("分页未收敛，可能反复重建恢复基线")

    def test_project_identity_survives_runtime_loss(self):
        project_id = self.store.status()["project"]["project_id"]
        self.publish()
        shutil.rmtree(self.root / ".coop")
        other = Store(self.root)
        self.assertEqual(project_id, other.ensure_initialized()["project_id"])
        self.assertEqual(1, len(other.events()))

    def test_noop_has_receipt_without_event(self):
        receipt = self.store.publish("codex", "reader", "T-1", {"noop": True, "turn_id": "turn-1"})
        self.assertTrue(receipt["noop"])
        self.assertFalse(receipt["published"])
        self.assertEqual([], self.store.events())
        found = self.store.get_receipt("codex", "reader", "turn-1")
        self.assertEqual("turn-1", found["turn_id"])
        writer = self.store.register("codex", "reader")["writer_id"]
        digest = hashlib.sha256(b"turn-1").hexdigest()[:20]
        self.assertTrue((self.root / ".coop/receipts" / writer / (digest + ".json")).exists())

    def test_unacknowledged_packet_is_replayed_then_delta_is_empty(self):
        self.publish()
        one = self.store.sync("codex", "reader", "T-1")
        two = self.store.sync("codex", "reader", "T-1")
        self.assertEqual(one["packet_id"], two["packet_id"])
        self.assertEqual(one["text"], two["text"])
        self.store.ack("codex", "reader", one["packet_id"])
        while one["has_more"]:
            one = self.store.sync("codex", "reader", "T-1")
            self.store.ack("codex", "reader", one["packet_id"])
        empty = self.store.sync("codex", "reader", "T-1")
        self.assertEqual("", empty["text"])
        self.assertIsNone(empty["packet_id"])

    def test_ack_cannot_be_stolen_by_other_session(self):
        packet = self.store.sync("codex", "one", "T-1")
        self.store.register("codex", "two", "T-1")
        with self.assertRaises(ValueError):
            self.store.ack("codex", "two", packet["packet_id"])
        self.store.ack("codex", "one", packet["packet_id"])

    def test_packet_from_previous_task_rejected_until_return(self):
        packet = self.store.sync("codex", "one", "T-1")
        self.store.sync("codex", "one", "T-2")
        with self.assertRaises(ValueError):
            self.store.ack("codex", "one", packet["packet_id"])

    def test_hundred_old_sessions_do_not_expand_default_recovery(self):
        for number in range(100):
            self.publish(number, session="history-" + str(number), handoff=["交给：无；本轮阶段完成。", f"完成：历史工作 {number}"])
        text, packets = self.drain()
        self.assertEqual(1, len(packets))
        self.assertLessEqual(packets[0]["estimated_tokens"], 2000)
        self.assertLessEqual(text.count("状态卡 trae-"), 3)
        self.assertIn("历史卡未自动加载", text)

    def test_new_same_tool_session_always_gets_recovery(self):
        self.publish()
        self.drain(session="old")
        packet = self.store.sync("codex", "new", "T-1")
        self.assertEqual("recover", packet["mode"])
        self.assertIn("发现 1", packet["text"])

    def test_hundred_durable_sessions_have_bounded_total_recovery(self):
        for number in range(100):
            self.publish(number, session="durable-" + str(number), durable=True,
                         handoff=["交给：用户；请核实当前方案。", "状态：历史讨论保留来源。"])
        text, packets = self.drain()
        self.assertEqual(1, len(packets))
        self.assertLessEqual(estimated_tokens(text), 2000)
        self.assertIn("未展开", text)
        self.assertIn("有效约束", text)
        self.assertIn("shared/current/T-1.md", text)
        self.assertTrue((self.root / "shared/current/T-1.p2.md").exists())

    def test_delta_pagination_does_not_lose_long_entries(self):
        self.drain()
        expected = []
        for number in range(15):
            result = self.publish(number, summary="长发现" + str(number) + "甲" * 90, why="乙" * 60, sources=["repro/运行材料/" + "丙" * 80])
            expected.extend(result["event_ids"])
        text, packets = self.drain(budget=500)
        self.assertGreater(len(packets), 15)
        self.assertTrue(any(packet["has_more"] for packet in packets))
        self.assertTrue(all(packet["estimated_tokens"] <= 500 for packet in packets))
        for event_id in expected:
            self.assertIn(event_id, text)
        self.assertEqual("", self.store.sync("codex", "reader", "T-1")["text"])

    def test_old_durable_pitfall_survives_tail(self):
        old = self.publish(0, summary="旧坑：不能跨版本比较", durable=True)["event_ids"][0]
        for number in range(65):
            self.publish(number + 1)
        self.assertNotIn(old, (self.root / "shared/log.md").read_text(encoding="utf-8"))
        text, _ = self.drain()
        self.assertIn(old, text)
        self.assertIn("旧坑", text)

    def test_superseding_event_removes_old_active_constraint(self):
        old = self.publish(0, summary="旧限制", durable=True)["event_ids"][0]
        for number in range(8):
            self.publish(number + 1)
        new = self.publish(99, summary="限制已修订", durable=True, supersedes=[old])["event_ids"][0]
        text, _ = self.drain()
        self.assertNotIn("旧限制", text)
        self.assertIn(new, text)

    def test_project_scope_constraints_follow_task_change(self):
        self.publish(1, task="T-SETUP", summary="全局：不得把提议当用户决定", scope="project", durable=True)
        self.publish(2, task="T-1", summary="只属于任务一")
        self.drain(task="T-1")
        text, _ = self.drain(task="T-2")
        self.assertIn("不得把提议", text)
        self.assertNotIn("只属于任务一", text)
        self.assertEqual("T-2", self.store.current_task("codex", "reader"))

    def test_missing_or_corrupt_cursor_can_explicitly_recover(self):
        self.publish()
        self.drain()
        state = self.store.get_session("codex", "reader")
        path = self.root / ".coop/sessions" / (state["writer_id"] + ".json")
        path.write_text("broken", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.store.sync("codex", "reader", "T-1")
        packet = self.store.sync("codex", "reader", "T-1", mode="recover")
        self.assertEqual("recover", packet["mode"])
        self.assertIn("发现 1", packet["text"])

    def test_new_task_index_exists_and_tracks_later_global_constraint(self):
        self.store.sync("codex", "reader", "T-NEW")
        index = self.root / "shared/current/T-NEW.md"
        self.assertTrue(index.exists())
        self.publish(task="T-SETUP", summary="后来新增的全局限制", scope="project", durable=True)
        self.assertIn("后来新增的全局限制", index.read_text(encoding="utf-8"))

    def test_malformed_task_state_can_explicitly_recover(self):
        self.drain()
        state = self.store.get_session("codex", "reader")
        state["tasks"] = "broken"
        path = self.root / ".coop/sessions" / (state["writer_id"] + ".json")
        path.write_text(json.dumps(state), encoding="utf-8")
        with self.assertRaises(ValueError):
            self.store.sync("codex", "reader", "T-1")
        self.assertEqual("recover", self.store.sync("codex", "reader", "T-1", mode="recover")["mode"])

    def test_force_recovery_invalidates_prior_pending_packet(self):
        old = self.store.sync("codex", "reader", "T-1")
        new = self.store.sync("codex", "reader", "T-1", mode="recover")
        self.assertNotEqual(old["packet_id"], new["packet_id"])
        with self.assertRaises(ValueError):
            self.store.ack("codex", "reader", old["packet_id"])

    def test_handoff_boundary_and_rebuild(self):
        card = ["交给：用户；请检查结果。"] + ["信息：" + str(number) for number in range(11)]
        result = self.publish(handoff=card)
        path = Path(result["handoff_path"])
        self.assertEqual(12, len(path.read_text(encoding="utf-8").splitlines()))
        path.write_text("damaged view", encoding="utf-8")
        self.assertTrue(self.store.doctor()["ok"])
        self.assertEqual(card, path.read_text(encoding="utf-8").splitlines())
        with self.assertRaises(ValueError):
            self.publish(2, handoff=card + ["第十三行"])
        with self.assertRaises(ValueError):
            self.publish(3, handoff=["没有接收人"])

    def test_adoption_needs_explicit_authority(self):
        with self.assertRaises(ValueError):
            self.publish(decision="adopted")
        result = self.publish(decision="adopted", authority="user", authority_source="本轮用户明确说采用")
        self.assertEqual(1, len(result["event_ids"]))
        with self.assertRaises(ValueError):
            self.publish(2, decision="proposed", supersedes=result["event_ids"])

    def test_obsolete_projection_pages_are_tombstoned(self):
        references = []
        for number in range(15):
            references += self.publish(number, durable=True)["event_ids"]
        page = self.root / "shared/current/T-1.p2.md"
        self.assertTrue(page.exists())
        self.publish(99, durable=True, supersedes=references)
        self.assertIn("已失效", page.read_text(encoding="utf-8"))
        self.assertEqual(16, len(self.store.events()))

    def test_card_from_writer_current_other_task_is_not_presented_as_current(self):
        self.publish(task="T-1", handoff=["交给：用户；请查看任务一。"])
        self.publish(2, task="T-2", handoff=["交给：用户；请查看任务二。"])
        text, _ = self.drain(task="T-1")
        self.assertNotIn("状态卡 trae-", text)
        self.assertNotIn("请查看任务一", text)

    def test_retry_same_turn_payload_is_idempotent(self):
        one = self.publish(turn_id="same-turn")
        two = self.publish(turn_id="same-turn")
        self.assertEqual(one["event_ids"], two["event_ids"])
        self.assertEqual([], two["appended"])
        self.assertEqual(1, len(self.store.events()))
        self.store.publish("trae", "writer", "T-1", {"noop": True, "turn_id": "same-turn"})
        self.assertTrue(self.store.get_receipt("trae", "writer", "same-turn")["published"])

    def test_machine_paths_cannot_escape_root(self):
        for tool in ("../outside", "foo/bar", ".."): 
            with self.assertRaises(ValueError):
                self.store.register(tool, "reader")
        with self.assertRaises(ValueError):
            self.store.sync("codex", "reader", "../../elsewhere")
        with self.assertRaises(ValueError):
            self.store.path("../outside")

    def test_summary_constraints_and_unknown_reference_rejected(self):
        for payload in ({"summary": "x" * 201}, {"summary": "一\n二"}, {"summary": "摘要", "supersedes": ["missing#1"]}):
            with self.assertRaises(ValueError):
                self.store.publish("codex", "reader", "T-1", payload)

    def test_boolean_flags_reject_strings_numbers_and_null(self):
        for key in ("durable", "noop"):
            for value in ("false", "true", 0, 1, None):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    self.store.publish("codex", "reader", "T-1", {"summary": "纯事实", key: value})
        self.store.publish("codex", "reader", "T-1", {"summary": "纯事实", "durable": False, "noop": False})
        self.assertFalse(self.store.events()[0]["durable"])

    def test_handoff_first_line_requires_receiver_and_action(self):
        for first in ("交给：用户", "交给：用户；", "交给：用户；   ", "交给：；请继续", "交给：   ;请继续"):
            with self.subTest(first=first), self.assertRaises(ValueError):
                self.publish(handoff=[first])
        self.publish(handoff=["交给：无；暂无下一步"])
        self.publish(2, handoff=["交给:用户;请核实结果"])

    def test_decision_related_events_require_reason_but_findings_do_not(self):
        for kind in ("direction", "decision", "user_decision", "failure", "abandoned"):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.store.publish("codex", "reader", "T-1", {"summary": "待记录", "kind": kind, "why": " "})
        with self.assertRaises(ValueError):
            self.store.publish("codex", "reader", "T-1", {"summary": "待记录", "decision": "proposed"})
        result = self.store.publish("codex", "reader", "T-1", {"summary": "实际观察到的事实", "kind": "finding"})
        self.assertEqual(1, len(result["event_ids"]))

    def test_torn_raw_append_is_reported_not_silently_skipped(self):
        self.publish()
        path = next((self.root / "shared/events").glob("*/*.jsonl"))
        with open(path, "ab") as stream:
            stream.write(b'{"unfinished":')
        with self.assertRaisesRegex(ValueError, "不完整末行"):
            self.store.events()

    def test_multiple_processes_publish_without_loss(self):
        source = "import sys;from pathlib import Path;sys.path.insert(0,sys.argv[1]);from core import Store;s=Store(Path(sys.argv[2]));[s.publish('codex',sys.argv[3],'T-1',{'summary':'item '+str(i),'kind':'finding'}) for i in range(8)]"
        processes = [subprocess.Popen([sys.executable, "-c", source, str(CORE_DIR), str(self.root), "process-" + str(number)], stdout=subprocess.PIPE, stderr=subprocess.PIPE) for number in range(4)]
        for process in processes:
            stdout, stderr = process.communicate(timeout=40)
            self.assertEqual(0, process.returncode, (stdout, stderr))
        events = self.store.events()
        self.assertEqual(32, len(events))
        self.assertEqual(32, len({event["event_id"] for event in events}))
        for writer in {event["writer_id"] for event in events}:
            self.assertEqual(list(range(1, 9)), sorted(event["seq"] for event in events if event["writer_id"] == writer))


if __name__ == "__main__":
    unittest.main()
