from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "tools" / "coop"))
from core import Store
from hooks import handle_event


class HookContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.ensure_initialized("hook contract fixture")

    def tearDown(self):
        self.temp.cleanup()

    def prompt(self, session="s1", turn="turn1", tool="codex"):
        return handle_event(self.store, tool, {"session_id": session,
            "hook_event_name": "UserPromptSubmit", "turn_id": turn,
            "cwd": str(self.root.parent)})

    def test_startup_does_not_duplicate_recovery_body(self):
        output = handle_event(self.store, "codex", {"session_id": "s1",
            "hook_event_name": "SessionStart", "source": "startup"})
        self.assertLess(len(output["hookSpecificOutput"]["additionalContext"]), 200)
        self.assertNotIn("packet=", output["hookSpecificOutput"]["additionalContext"])
        startup_size = len(output["hookSpecificOutput"]["additionalContext"].encode("utf-8"))
        output = self.prompt()
        self.assertIn("packet=", output["hookSpecificOutput"]["additionalContext"])
        self.assertLessEqual(startup_size + len(output["hookSpecificOutput"]["additionalContext"].encode("utf-8")), 2000)
        pending = self.store.sync("codex", "s1")
        self.assertEqual(pending["mode"], "recover")

    def test_sync_is_not_implicitly_acknowledged(self):
        first = self.prompt()
        pending = self.store.sync("codex", "s1")
        again = self.prompt()
        self.assertEqual(pending["packet_id"], self.store.sync("codex", "s1")["packet_id"])
        self.assertIn(pending["packet_id"], first["hookSpecificOutput"]["additionalContext"])
        again_text = again["hookSpecificOutput"]["additionalContext"]
        if pending["packet_id"] not in again_text:
            self.assertIn("NOT injected", again_text)

    def test_stop_requires_this_turn_receipt_and_only_reminds_once(self):
        self.prompt()
        data = {"session_id": "s1", "hook_event_name": "Stop", "turn_id": "turn1"}
        self.assertEqual(handle_event(self.store, "codex", data)["decision"], "block")
        self.assertNotIn("decision", handle_event(self.store, "codex", data))

    def test_receipt_from_another_turn_does_not_satisfy_stop(self):
        self.store.publish("codex", "s1", "T-START", {"noop": True, "turn_id": "old"})
        self.prompt()
        output = handle_event(self.store, "codex", {"session_id": "s1",
            "hook_event_name": "Stop", "turn_id": "turn1"})
        self.assertEqual(output["decision"], "block")

    def test_noop_receipt_can_ack_and_allow_stop_without_log_pollution(self):
        self.prompt()
        packet = self.store.sync("codex", "s1")
        self.store.publish("codex", "s1", "T-START", {"noop": True,
            "turn_id": "turn1", "ack_packet": packet["packet_id"]})
        self.assertEqual(handle_event(self.store, "codex", {"session_id": "s1",
            "hook_event_name": "Stop", "turn_id": "turn1"}), {})
        self.assertEqual(self.store.events(), [])
        self.assertTrue(self.store.sync("codex", "s1")["unchanged"])

    def test_task_changed_via_cli_is_preserved(self):
        self.store.register("codex", "s1", "T-OTHER")
        self.prompt()
        self.assertEqual(self.store.current_task("codex", "s1"), "T-OTHER")

    def test_trae_without_turn_id_gets_distinct_real_message_turns(self):
        data = {"session_id": "s1", "hook_event_name": "UserPromptSubmit", "prompt": "继续"}
        handle_event(self.store, "trae", data)
        writer = self.store.register("trae", "s1")["writer_id"]
        state_path = self.root / ".coop/hook-state" / (writer + ".json")
        first = json.loads(state_path.read_text(encoding="utf-8"))["turn_id"]
        handle_event(self.store, "trae", data)
        second = json.loads(state_path.read_text(encoding="utf-8"))["turn_id"]
        self.assertNotEqual(first, second)

    def test_missing_native_session_is_not_shared_unknown_session(self):
        with self.assertRaisesRegex(ValueError, "session_id"):
            handle_event(self.store, "codex", {"hook_event_name": "UserPromptSubmit"})

    def test_native_stop_reentry_does_not_loop(self):
        self.prompt(tool="trae")
        output = handle_event(self.store, "trae", {"session_id": "s1",
            "hook_event_name": "Stop", "stop_hook_active": True, "loop_count": 1})
        self.assertNotIn("decision", output)

    def test_stdio_adapter_uses_explicit_root_not_cwd(self):
        run = subprocess.run([sys.executable, str(PROJECT / "tools/coop/hooks.py"),
            "--tool", "codex", "--root", str(self.root)],
            input=json.dumps({"session_id": "s-stdio", "turn_id": "t-stdio",
                "hook_event_name": "UserPromptSubmit", "cwd": str(self.root.parent)}),
            cwd=self.root.parent, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(run.returncode, 0, run.stderr)
        result = json.loads(run.stdout)
        self.assertIn("s-stdio", result["hookSpecificOutput"]["additionalContext"])

    def test_bad_stdio_input_is_visible_failure(self):
        run = subprocess.run([sys.executable, str(PROJECT / "tools/coop/hooks.py"),
            "--tool", "codex", "--root", str(self.root)], input="{", capture_output=True,
            text=True, encoding="utf-8")
        self.assertEqual(run.returncode, 1)
        self.assertIn("未声称已完成", run.stdout)

    def _drain(self, tool, session):
        for _ in range(100):
            packet = self.store.sync(tool, session)
            if not packet.get("packet_id"):
                return
            self.store.ack(tool, session, packet["packet_id"])
        self.fail("fixture recovery did not finish")

    def _fill_updates(self, prefix):
        for index in range(8):
            self.store.publish("trae", "producer", "T-START", {
                "summary": prefix + str(index), "why": "验证预算时保留足够多的新增条目，确保同步正文需要分页。"})

    def test_total_additional_context_budgets_include_native_metadata(self):
        self._fill_updates("历史")
        for width in (36, 64):
            for tool in ("codex", "trae", "workbuddy", "deepseekharness"):
                session = (tool[0] * width)
                first = self.prompt(session, "r" * width, tool)
                text = first["hookSpecificOutput"]["additionalContext"]
                self.assertLessEqual(len(text.encode("utf-8")), 2000,
                                     (tool, width, len(text.encode("utf-8"))))
                self._drain(tool, session)
                self._fill_updates("新增" + tool + str(width))
                output = self.prompt(session, "d" * width, tool)
                text = output["hookSpecificOutput"]["additionalContext"]
                self.assertLessEqual(len(text.encode("utf-8")), 500,
                                     (tool, width, len(text.encode("utf-8"))))

    def test_extremely_long_native_ids_use_explicit_metadata_index(self):
        session, turn = "s" * 1024, "t" * 1024
        result = self.prompt(session, turn)
        text = result["hookSpecificOutput"]["additionalContext"]
        self.assertLessEqual(len(text.encode("utf-8")), 2000)
        self.assertIn("meta=", text)
        self.assertNotIn(session, text)
        identity = self.store.register("codex", session)
        meta = json.loads((self.root / ".coop/hook-meta" /
            (identity["writer_id"] + ".json")).read_text(encoding="utf-8"))
        self.assertEqual(meta["session"], session)
        self.assertEqual(meta["turn_id"], turn)
        self.assertTrue(meta["packet_body_delivered"])

    def test_large_manual_pending_packet_gets_index_not_truncated_delivery(self):
        self.prompt()
        self._drain("codex", "s1")
        self._fill_updates("大待交付包")
        pending = self.store.sync("codex", "s1", budget=8000)
        self.assertGreater(len(pending["text"].encode("utf-8")), 500)
        result = self.prompt(turn="next-turn")
        text = result["hookSpecificOutput"]["additionalContext"]
        self.assertLessEqual(len(text.encode("utf-8")), 500)
        self.assertIn("NOT injected", text)
        self.assertIn("NOT advanced", text)
        identity = self.store.register("codex", "s1")
        meta = json.loads((self.root / ".coop/hook-meta" /
            (identity["writer_id"] + ".json")).read_text(encoding="utf-8"))
        self.assertFalse(meta["packet_body_delivered"])
        saved = json.loads((self.root / meta["pending_file"]).read_text(encoding="utf-8"))
        self.assertEqual(saved["text"], pending["text"])
        self.assertEqual(self.store.sync("codex", "s1")["packet_id"], pending["packet_id"])

    @unittest.skipUnless(os.name == "nt", "Windows shell contract")
    def test_installed_codex_command_shell_quoting(self):
        config = json.loads((PROJECT / ".codex/hooks.json").read_text(encoding="utf-8"))
        command = config["hooks"]["UserPromptSubmit"][0]["hooks"][0]["command"]
        command = command.replace("--root '" + str(PROJECT) + "'", "--root '" + str(self.root) + "'")
        run = subprocess.run(command, shell=True, input=json.dumps({"session_id": "shell-probe",
            "turn_id": "turn-shell", "hook_event_name": "UserPromptSubmit"}),
            capture_output=True, text=True, encoding="utf-8", cwd=self.root.parent)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("hookSpecificOutput", json.loads(run.stdout))


if __name__ == "__main__":
    unittest.main()
