"""Behavioral checks in disposable projects, never in the thesis event history."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools" / "coop"))
from core import Store
from runs import run_recorded
from outcomes import create_candidate, decide_candidate
from coop import backup


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="coop-integration-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = Store(self.root)
        self.store.ensure_initialized()

    def script(self, content):
        path = self.root / "实验.py"
        path.write_text(content, encoding="utf-8")
        return path

    def test_failure_preserves_command_and_inputs_before_execution(self):
        script = self.script("import sys\nprint('observed output')\nsys.exit(7)\n")
        result = run_recorded(self.store, "codex", "run-test", "T-RUN", [sys.executable, str(script)], captures=[str(script)])
        folder = Path(result["directory"])
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["returncode"], 7)
        self.assertEqual(manifest["status"], "failed")
        self.assertEqual(manifest["evidence_state"], "unverified")
        self.assertEqual(manifest["argv"], [sys.executable, str(script)])
        self.assertIn("observed output", (folder / "stdout.log").read_text())
        self.assertEqual((folder / "snapshot" / script.name).read_bytes(), script.read_bytes())
        self.assertIn("prepared_at", manifest)
        self.assertEqual(len(self.store.events("T-RUN")), 2)

    def test_detects_changed_declared_input_without_false_isolation_claim(self):
        value = self.root / "input.txt"
        value.write_text("before", encoding="utf-8")
        script = self.script("from pathlib import Path\nPath('input.txt').write_text('after', encoding='utf-8')\n")
        result = run_recorded(self.store, "trae", "run-test", "T-RUN", [sys.executable, str(script)],
                              inputs=[str(value)], captures=[str(script)])
        folder = Path(result["directory"])
        self.assertIn(str(value), result["changed_sources"])
        self.assertEqual((folder / "snapshot" / "input.txt").read_text(), "before")
        self.assertEqual(value.read_text(), "after")

    def test_missing_input_fails_before_process_launch(self):
        marker = self.root / "should-not-exist.txt"
        with self.assertRaises(ValueError):
            run_recorded(self.store, "codex", "bad-input", "T-RUN",
                         [sys.executable, "-c", f"open({str(marker)!r},'w').write('wrong')"], inputs=["missing-input.txt"])
        self.assertFalse(marker.exists())
        manifest = next((self.root / "repro").glob("*/manifest.json"))
        self.assertEqual(json.loads(manifest.read_text(encoding="utf-8"))["status"], "capture_or_execution_error")

    def test_no_capture_requires_explicit_probe_opt_in(self):
        with self.assertRaises(ValueError):
            run_recorded(self.store, "codex", "no-input", "T-RUN", [sys.executable, "-c", "pass"])

    def test_candidate_requires_existing_sources_and_real_decision_fields(self):
        with self.assertRaises(ValueError):
            create_candidate(self.store, "codex", "candidate", "T-C", {"title": "x", "body": "x", "sources": ["not-here.md"]})
        source = self.root / "evidence.md"
        source.write_text("synthetic fixture evidence", encoding="utf-8")
        candidate = create_candidate(self.store, "workbuddy", "candidate", "T-C",
                                     {"title": "Fixture", "body": "Explicitly unverified fixture.", "sources": ["evidence.md"]})
        with self.assertRaises(ValueError):
            decide_candidate(self.store, "codex", "review", "T-C", candidate["id"], "accept", "", "")
        result = decide_candidate(self.store, "codex", "review", "T-C", candidate["id"], "accept",
                                  "Synthetic test decision, not a real thesis acceptance", "test_fixture:user_instruction")
        self.assertEqual(result["status"], "accepted")
        self.assertTrue((self.root / "outcomes" / "accepted" / "design" / (candidate["id"] + ".md")).exists())
        self.assertEqual(self.store.events("T-C")[-1]["authority"], "user")
        with self.assertRaises(ValueError):
            decide_candidate(self.store, "codex", "review", "T-C", candidate["id"], "reject", "do not rewrite", "test_fixture:user_instruction")

    def test_candidate_path_traversal_is_rejected(self):
        (self.root / "evidence.md").write_text("fixture")
        with self.assertRaises(ValueError):
            create_candidate(self.store, "codex", "candidate", "T-C",
                             {"id": "../../outside", "title": "x", "body": "x", "sources": ["evidence.md"]})

    def test_backup_preserves_sources_and_excludes_ephemeral_state(self):
        self.store.publish("codex", "backup", "T-B", {"summary": "Fixture", "why": "Backup test"})
        result = backup(self.root, self.root / "backups" / "fixture.zip")
        with zipfile.ZipFile(result["path"]) as archive:
            names = archive.namelist()
            self.assertTrue(any(name.startswith("shared/events/") for name in names))
            self.assertFalse(any(name.startswith(".coop/") for name in names))
            manifest = json.loads(archive.read("BACKUP_MANIFEST.json"))
            for entry in manifest["files"]:
                self.assertEqual(hashlib.sha256(archive.read(entry["path"])).hexdigest(), entry["sha256"])
        with self.assertRaises(ValueError):
            backup(self.root, result["path"])

    def test_four_tool_cli_handoff_and_return_to_existing_session(self):
        entry = Path(__file__).resolve().parents[1] / "tools" / "coop" / "coop.py"
        def cli(*args):
            result = subprocess.run([sys.executable, str(entry), "--root", str(self.root), *args],
                                    capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            return json.loads(result.stdout)
        def sync(tool, session):
            packet = cli("sync", "--tool", tool, "--session", session, "--task", "T-CHAIN", "--format", "json")
            if packet["packet_id"]:
                cli("ack", "--tool", tool, "--session", session, "--task", "T-CHAIN", "--packet", packet["packet_id"])
            return packet
        sync("trae", "paper-session")
        payload = self.root / "fixture.json"
        payload.write_text(json.dumps({"kind": "direction", "summary": "Fixture direction A", "why": "Fixture paper evidence",
                                       "decision": "proposed", "evidence": "unverified"}), encoding="utf-8")
        cli("publish", "--tool", "trae", "--session", "paper-session", "--task", "T-CHAIN", "--input", str(payload))
        self.assertIn("Fixture direction A", sync("workbuddy", "experiment-session")["text"])
        payload.write_text(json.dumps({"kind": "finding", "summary": "Fixture hypothesis B failed", "why": "Fixture output disagreed",
                                       "evidence": "failed"}), encoding="utf-8")
        cli("publish", "--tool", "workbuddy", "--session", "experiment-session", "--task", "T-CHAIN", "--input", str(payload))
        for tool, session in (("codex", "analysis-session"), ("deepseekharness", "review-session")):
            packet = sync(tool, session)
            self.assertIn("Fixture direction A", packet["text"])
            self.assertIn("Fixture hypothesis B failed", packet["text"])
            self.assertFalse(packet["has_more"])
        returned = sync("trae", "paper-session")
        self.assertEqual(returned["mode"], "delta")
        self.assertIn("Fixture hypothesis B failed", returned["text"])
        while returned["has_more"]:
            returned = sync("trae", "paper-session")
        self.assertEqual(sync("trae", "paper-session")["text"], "")


if __name__ == "__main__":
    unittest.main()
