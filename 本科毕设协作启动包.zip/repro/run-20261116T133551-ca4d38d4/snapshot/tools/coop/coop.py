#!/usr/bin/env python3
"""Project-local collaboration CLI. Run --help; no third-party dependencies."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import uuid
import zipfile

from core import Store, file_lock


TOOLS = ("codex", "trae", "workbuddy", "deepseekharness")


def output(value):
    print(json.dumps(value, ensure_ascii=False, indent=2))


def identity(parser, require_session=True):
    parser.add_argument("--tool", choices=TOOLS, required=True)
    parser.add_argument("--session", required=require_session)
    parser.add_argument("--task", default="T-START")


def load_json(path):
    text = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8-sig")
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("输入必须是JSON对象")
    return value


def backup(root, destination):
    from runs import digest
    target = Path(destination).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise ValueError("备份目标已存在；使用新文件名以保留历史")
    paths = []
    for top in ("AGENTS.md", "START_HERE.md", ".gitignore", "shared", "handoff", "repro", "outcomes", "tools", "tests", ".codex", ".trae", ".codebuddy", ".agents", ".dsh"):
        item = root / top
        if not item.exists():
            continue
        for file in ([item] if item.is_file() else sorted(item.rglob("*"))):
            if not file.is_file() or file.resolve() == target:
                continue
            if any(part in {"__pycache__", ".git", ".coop", "node_modules", ".venv", "backups"} for part in file.relative_to(root).parts):
                continue
            paths.append(file)
    manifest = {"schema_version": 1, "created_at": datetime.now(timezone.utc).isoformat(),
                "root": str(root), "files": []}
    try:
        with file_lock(root / ".coop" / "locks" / "store.lock"), zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for file in paths:
                name = file.relative_to(root).as_posix()
                before = digest(file)
                archive.write(file, name)
                if digest(file) != before:
                    raise ValueError(f"备份时文件变化，请在写入静止后重试: {name}")
                manifest["files"].append({"path": name, "sha256": before, "size": file.stat().st_size})
            archive.writestr("BACKUP_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        with zipfile.ZipFile(target) as archive:
            if archive.testzip():
                raise ValueError("备份CRC校验失败")
            for item in manifest["files"]:
                if hashlib.sha256(archive.read(item["path"])).hexdigest() != item["sha256"]:
                    raise ValueError("备份内容哈希校验失败: " + item["path"])
    except BaseException:
        # Preserve failed evidence, never disguise an incomplete ZIP as a verified backup.
        failed = target.with_suffix(target.suffix + ".incomplete")
        if target.exists() and not failed.exists():
            target.rename(failed)
        raise
    return {"path": str(target), "files": len(manifest["files"]), "sha256": digest(target), "verified": True,
            "note": "备份未包含可重建的.coop会话游标；恢复后应重新读取恢复包。"}


def build_parser():
    parser = argparse.ArgumentParser(description="本科毕设项目协作：按任务同步、按会话分写、运行前留证。")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init", help="幂等建立项目身份和缺失目录")
    p.add_argument("--name", default="本科毕设")
    p = sub.add_parser("session", help="没有hook时创建一次会话身份；后续复用返回的session")
    identity(p, False)
    p = sub.add_parser("sync", help="只准备同步包；成功读取后用ack或publish.ack_packet确认")
    identity(p)
    p.add_argument("--mode", choices=("auto", "recover"), default="auto")
    p.add_argument("--budget", type=int)
    p.add_argument("--format", choices=("markdown", "json"), default="markdown")
    p.add_argument("--turn")
    p = sub.add_parser("ack", help="仅确认当前会话实际收到的同步包")
    identity(p)
    p.add_argument("--packet", required=True)
    p = sub.add_parser("publish", help="发布一个有来源的进展事件；用--input文件避免shell转义")
    identity(p)
    p.add_argument("--input", required=True)
    p.add_argument("--turn")
    p = sub.add_parser("receipt", help="无变化轮次仅写机器收据，不污染过程日志")
    identity(p)
    p.add_argument("--noop", action="store_true", required=True)
    p.add_argument("--turn", required=True)
    p.add_argument("--ack")
    p = sub.add_parser("events", help="人工追查时按任务查询原始事件，不作为默认开场读取")
    p.add_argument("--task")
    p.add_argument("--limit", type=int, default=20)
    for command in ("status", "doctor"):
        sub.add_parser(command)
    p = sub.add_parser("run", help="先采集显式代码与输入，再按参数数组执行命令并保存输出")
    identity(p)
    p.add_argument("--input", action="append", default=[])
    p.add_argument("--capture", action="append", default=[])
    p.add_argument("--label", default="运行")
    p.add_argument("--cwd")
    p.add_argument("--allow-no-inputs", action="store_true")
    p.add_argument("argv", nargs=argparse.REMAINDER)
    p = sub.add_parser("candidate", help="由有来源的正文创建待裁决成果候选")
    identity(p)
    p.add_argument("--input", required=True)
    p = sub.add_parser("decide", help="记录真实用户裁决并收录或否决候选；不得agent自批")
    identity(p)
    p.add_argument("--candidate", required=True)
    p.add_argument("--decision", choices=("accept", "reject"), required=True)
    p.add_argument("--reason", required=True)
    p.add_argument("--source", required=True, help="可定位的真实用户裁决，不得捏造授权")
    p = sub.add_parser("backup", help="备份原始记录与设施，逐文件校验，排除游标与缓存")
    p.add_argument("--output", required=True)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    store = Store(args.root.resolve())
    try:
        if args.command == "init":
            result = store.ensure_initialized(args.name)
        elif args.command == "session":
            native = args.session or "manual-" + uuid.uuid4().hex
            result = dict(store.register(args.tool, native, args.task), session=native, tool=args.tool, task=args.task)
        elif args.command == "sync":
            result = store.sync(args.tool, args.session, args.task, args.mode, args.budget)
            if args.format == "markdown":
                print(result["text"])
                if result.get("packet_id"):
                    print("\n同步包：" + result["packet_id"])
                    print("实际读取后确认：python tools/coop/coop.py ack --tool " + args.tool +
                          " --session " + args.session + " --task " + args.task + " --packet " + result["packet_id"])
                if result.get("has_more"):
                    print("尚有未交付内容：确认本包后继续同步，不得声称已读完。")
                return 0
        elif args.command == "ack":
            result = store.ack(args.tool, args.session, args.packet)
        elif args.command == "publish":
            payload = load_json(args.input)
            if args.turn:
                payload["turn_id"] = args.turn
            result = store.publish(args.tool, args.session, args.task, payload)
        elif args.command == "receipt":
            result = store.publish(args.tool, args.session, args.task,
                                   {"noop": True, "turn_id": args.turn, "ack_packet": args.ack})
        elif args.command == "events":
            if args.limit < 1 or args.limit > 200:
                raise ValueError("limit应在1到200之间；按需分页追查")
            result = store.events(args.task)[-args.limit:]
        elif args.command in {"status", "doctor"}:
            result = getattr(store, args.command)()
        elif args.command == "run":
            from runs import run_recorded
            command = args.argv[1:] if args.argv and args.argv[0] == "--" else args.argv
            result = run_recorded(store, args.tool, args.session, args.task, command,
                                  cwd=args.cwd, inputs=args.input, captures=args.capture,
                                  label=args.label, allow_no_inputs=args.allow_no_inputs)
            output(result)
            return result.get("returncode", 1)
        elif args.command == "candidate":
            from outcomes import create_candidate
            result = create_candidate(store, args.tool, args.session, args.task, load_json(args.input))
        elif args.command == "decide":
            from outcomes import decide_candidate
            result = decide_candidate(store, args.tool, args.session, args.task, args.candidate,
                                      args.decision, args.reason, args.source)
        elif args.command == "backup":
            result = backup(store.root, args.output)
        else:
            raise ValueError("未知操作")
        output(result)
        return 0
    except (ValueError, OSError, RuntimeError, json.JSONDecodeError, KeyError, TypeError) as exc:
        output({"ok": False, "error": f"{type(exc).__name__}: {exc}", "note": "操作未确认完成；勿把未写入或未交付内容当作已同步。"})
        return 2


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    raise SystemExit(main())
