"""Local, bounded collaboration records. Python 3.10+, standard library only.

JSONL events are authoritative. Markdown files and reader cursors are projections.
The token estimate is deliberately an UTF-8 byte upper bound, not a tokenizer.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import tempfile
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = 1
TOOLS = ("codex", "trae", "workbuddy", "deepseekharness")
IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
DECISIONS = {None, "proposed", "adopted", "rejected", "superseded"}
EVIDENCE = {None, "unverified", "supported", "failed", "uncertain"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def estimated_tokens(text: str) -> int:
    """Conservative upper bound; ordinary tokenizers use no more than UTF-8 bytes."""
    return len(text.encode("utf-8"))


def atomic_json(path: Path, data: Any) -> None:
    atomic_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def atomic_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") == text:
        return
    fd, name = tempfile.mkstemp(prefix=".coop-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


@contextmanager
def file_lock(path: Path, timeout: float = 15):
    """An OS lock, automatically released on process exit; no stale PID guessing."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"\0")
            stream.flush()
        deadline = time.monotonic() + timeout
        while True:
            try:
                stream.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except (OSError, BlockingIOError):
                if time.monotonic() >= deadline:
                    raise TimeoutError("协作记录锁超时；本次写入尚未完成")
                time.sleep(0.03)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def _identifier(value: str, label: str) -> str:
    if not isinstance(value, str) or not IDENTIFIER.fullmatch(value) or value in (".", ".."):
        raise ValueError(f"{label} 必须是1至80位安全标识（字母、数字、下划线、点、连字符）")
    return value


def _json(path: Path, default=None):
    if not path.exists():
        return copy.deepcopy(default)
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (ValueError, UnicodeError) as error:
        raise ValueError(f"机器状态损坏：{path}；请先备份再用 recover 重建读取状态") from error


class Store:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()

    def path(self, *parts: str) -> Path:
        candidate = self.root.joinpath(*parts).resolve()
        if candidate != self.root and self.root not in candidate.parents:
            raise ValueError("路径越出项目目录（包括符号链接/联接点）")
        return candidate

    @contextmanager
    def _locked(self):
        self.root.mkdir(parents=True, exist_ok=True)
        with file_lock(self.path(".coop", "locks", "store.lock")):
            yield

    def _ensure(self, name="本科毕设") -> dict:
        for item in ("shared/events", "shared/current", "handoff", "repro", "outcomes/candidates", "outcomes/accepted", ".coop/sessions", ".coop/receipts"):
            self.path(item).mkdir(parents=True, exist_ok=True)
        project_path = self.path("shared", "project.json")
        if not project_path.exists():
            atomic_json(project_path, {"schema": SCHEMA, "project_id": str(uuid.uuid4()), "name": name, "created_at": utc_now(), "protocol_version": 1})
        project = _json(project_path)
        if not isinstance(project, dict) or not project.get("project_id"):
            raise ValueError("shared/project.json 缺少项目标识；不能默默生成新项目覆盖历史")
        return project

    def ensure_initialized(self, name="本科毕设") -> dict:
        with self._locked():
            project = self._ensure(name)
            self._project_views(self._events())
            return project

    def _identity(self, tool: str, session: str) -> dict:
        tool = _identifier(tool.lower(), "tool")
        if not isinstance(session, str) or not session.strip() or len(session) > 1024:
            raise ValueError("session 必须是当前会话的非空稳定标识，最长1024字符")
        digest = hashlib.sha256((tool + "\0" + session).encode("utf-8")).hexdigest()[:20]
        return {"writer_id": f"{tool}-{digest}", "session_key": f"{tool}-{digest}", "tool": tool, "native_session": session}

    def _state_path(self, identity: dict) -> Path:
        return self.path(".coop", "sessions", identity["session_key"] + ".json")

    def _state(self, identity: dict, task: str, recover=False) -> dict:
        try:
            state = _json(self._state_path(identity), {})
        except ValueError:
            if not recover:
                raise
            state = {}
        if not isinstance(state, dict):
            if not recover:
                raise ValueError("读取状态格式错误；使用 recover 建立新恢复基线")
            state = {}
        if state and (not isinstance(state.get("tasks", {}), dict) or state.get("writer_id", identity["writer_id"]) != identity["writer_id"]):
            if not recover:
                raise ValueError("读取状态的会话归属或任务结构错误；使用 recover 重建")
            state = {}
        state.setdefault("schema", SCHEMA)
        state.setdefault("writer_id", identity["writer_id"])
        state.setdefault("tool", identity["tool"])
        state.setdefault("native_session", identity["native_session"])
        state.setdefault("tasks", {})
        state.setdefault("created_at", utc_now())
        state["task"] = task
        return state

    def register(self, tool, session, task="T-START") -> dict:
        task = _identifier(task, "task")
        with self._locked():
            self._ensure()
            identity = self._identity(tool, session)
            state = self._state(identity, task)
            state["updated_at"] = utc_now()
            atomic_json(self._state_path(identity), state)
            return {**identity, "task": task, "project_id": self._ensure()["project_id"]}

    def current_task(self, tool, session) -> str:
        with self._locked():
            self._ensure()
            identity = self._identity(tool, session)
            state = _json(self._state_path(identity), {})
            return state.get("task", "T-START")

    def get_session(self, tool, session) -> dict:
        with self._locked():
            self._ensure()
            identity = self._identity(tool, session)
            return _json(self._state_path(identity), {})

    @staticmethod
    def _relevant(event, task):
        return event["task"] in (task, "GLOBAL") or event.get("scope") == "project"

    def _events(self) -> list:
        result = []
        for path in sorted(self.path("shared/events").glob("*/*.jsonl")):
            self.path(str(path.relative_to(self.root)))
            raw = path.read_bytes()
            if raw and not raw.endswith(b"\n"):
                raise ValueError(f"原始日志存在不完整末行：{path}；保留原文件并修复，禁止跳过")
            for line_number, line in enumerate(raw.splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    item = json.loads(line.decode("utf-8"))
                except (ValueError, UnicodeError) as error:
                    raise ValueError(f"原始日志损坏：{path}:{line_number}；禁止忽略") from error
                if not isinstance(item, dict) or not item.get("event_id") or not isinstance(item.get("seq"), int):
                    raise ValueError(f"原始日志结构错误：{path}:{line_number}")
                result.append(item)
        result.sort(key=lambda event: (event["time"], event["writer_id"], event["seq"]))
        ids = [event["event_id"] for event in result]
        if len(ids) != len(set(ids)):
            raise ValueError("存在重复原始事件ID；请保留日志并人工检查")
        return result

    def events(self, task=None) -> list:
        if task is not None:
            _identifier(task, "task")
        with self._locked():
            self._ensure()
            events = self._events()
            return [event for event in events if task is None or self._relevant(event, task)]

    @staticmethod
    def _active(events: list) -> list:
        replaced = {reference for event in events for reference in event.get("supersedes", [])}
        return [event for event in events if event["event_id"] not in replaced and event.get("decision") != "superseded"]

    @staticmethod
    def _event_line(event: dict) -> str:
        text = event["summary"]
        if event.get("why"):
            text += "；理由：" + event["why"]
        if event.get("impact"):
            text += "；影响：" + event["impact"]
        states = "/".join(filter(None, (event.get("decision"), event.get("evidence"))))
        prefix = f"{event['event_id']} [{event['task']}:{event['kind']}"
        if states:
            prefix += ":" + states
        return prefix + "] " + text

    def _cards(self, events: list, task=None) -> dict:
        cards = {}
        for event in events:
            if "handoff" in event:
                cards[event["writer_id"]] = {"event": event, "text": "\n".join(event["handoff"]) + "\n"}
        return {writer: card for writer, card in cards.items() if task is None or Store._relevant(card["event"], task)}

    def _project_views(self, events: list, extra_tasks=()) -> None:
        lines = [self._event_line(event) for event in events[-50:]]
        atomic_text(self.path("shared/log.md"), "\n".join(lines) + ("\n" if lines else ""))
        for writer, card in self._cards(events).items():
            atomic_text(self.path("handoff", writer + ".md"), card["text"])
        previous_tasks = {path.stem for path in self.path("shared/current").glob("*.md") if not re.search(r"\.p\d+$", path.stem)}
        tasks = sorted({event["task"] for event in events} | previous_tasks | set(extra_tasks))
        for task in tasks:
            relevant = [event for event in events if self._relevant(event, task)]
            active = self._active(relevant)
            durable = [event for event in active if event.get("durable")]
            outstanding = [event for event in active if event.get("decision") == "proposed" or event.get("evidence") in ("failed", "uncertain")]
            selected = {event["event_id"]: event for event in durable + outstanding[-10:] + relevant[-5:]}
            ordered = list(selected.values())
            # A one-screen index, not a lossy authority: all numbered pages remain reachable.
            page_size = 12
            pages = [ordered[i:i + page_size] for i in range(0, len(ordered), page_size)] or [[]]
            for index, page in enumerate(pages, 1):
                filename = task + ("" if index == 1 else f".p{index}") + ".md"
                heading = f"任务 {task}：有效约束 {len(durable)}；待处理条目 {len(outstanding)}；当前页 {index}/{len(pages)}。\n"
                body = "\n".join(self._event_line(event) for event in page)
                following = "\n" + f"续页：shared/current/{task}.p{index + 1}.md" if index < len(pages) else ""
                atomic_text(self.path("shared/current", filename), heading + body + following + "\n")
            for stale in self.path("shared/current").glob(task + ".p*.md"):
                match = re.fullmatch(re.escape(task) + r"\.p(\d+)\.md", stale.name)
                if match and int(match.group(1)) > len(pages):
                    atomic_text(stale, f"此派生页已失效；当前索引：shared/current/{task}.md。原始事件仍完整保留。\n")

    def _validate_payload(self, payload: dict, events: list) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("publish 输入必须是JSON对象")
        payload = copy.deepcopy(payload)
        for key in ("noop", "durable"):
            if key in payload and not isinstance(payload[key], bool):
                raise ValueError(f"{key} 必须是JSON布尔值 true/false，不能使用字符串或数字")
        if payload.get("noop"):
            if payload.get("handoff") or payload.get("summary"):
                raise ValueError("noop 不能携带新事件或状态卡修改")
            return payload
        for key in ("summary", "why", "impact"):
            value = payload.get(key, "")
            if not isinstance(value, str) or "\n" in value or "\r" in value:
                raise ValueError(f"{key} 必须为单行文本")
            payload[key] = value.strip()
        if not payload["summary"]:
            raise ValueError("summary 不能为空")
        if sum(len(payload[key]) for key in ("summary", "why", "impact")) > 200:
            raise ValueError("摘要、理由、影响合计不能超过200字符；请把详论存为产出并留指针")
        payload["kind"] = _identifier(payload.get("kind", "progress"), "kind")
        if payload.get("scope", "task") not in ("task", "project"):
            raise ValueError("scope 必须是 task 或 project")
        if payload.get("decision") not in DECISIONS:
            raise ValueError("decision 不合法")
        if payload.get("evidence") not in EVIDENCE:
            raise ValueError("evidence 不合法")
        if (payload.get("decision") is not None or payload["kind"] in {"direction", "decision", "user_decision", "failure", "abandoned"}) and not payload["why"]:
            raise ValueError("决策、方向、失败或放弃方案必须提供非空why；纯事实finding可以不填理由")
        if payload.get("decision") == "adopted" and not (payload.get("authority") == "user" and str(payload.get("authority_source", "")).strip()):
            raise ValueError("adopted 必须注明 authority=user 与 authority_source；不能代替用户作决定")
        for key in ("sources", "supersedes"):
            values = payload.get(key, [])
            if not isinstance(values, list) or any(not isinstance(value, str) or not value or "\n" in value or "\r" in value for value in values):
                raise ValueError(f"{key} 必须是非空单行字符串列表")
            payload[key] = values
        available = {event["event_id"] for event in events}
        if any(reference not in available for reference in payload["supersedes"]):
            raise ValueError("supersedes 引用了不存在的事件")
        adopted = {event["event_id"] for event in events if event.get("decision") == "adopted"}
        if adopted.intersection(payload["supersedes"]) and not (payload.get("authority") == "user" and str(payload.get("authority_source", "")).strip()):
            raise ValueError("替代已采纳的用户决定必须注明用户授权来源；agent建议应单独作为proposed记录")
        if "handoff" in payload:
            card = payload["handoff"]
            if not isinstance(card, list) or not 1 <= len(card) <= 12 or any(not isinstance(line, str) or "\n" in line or "\r" in line for line in card):
                raise ValueError("handoff 必须是1至12行的字符串列表")
            first_line = re.fullmatch(r"交给[：:]\s*([^；;]+)[；;]\s*(\S.*)", card[0])
            if not first_line or not first_line.group(1).strip():
                raise ValueError("handoff 首行必须为：交给：接收者；请做什么")
            if any(len(line) > 200 for line in card):
                raise ValueError("交接卡单行不能超过200字符")
        payload["durable"] = bool(payload.get("durable", False))
        return payload

    def _receipt_path(self, writer: str, turn_id: str) -> Path:
        digest = hashlib.sha256(turn_id.encode("utf-8")).hexdigest()[:20]
        return self.path(".coop/receipts", writer, digest + ".json")

    def get_receipt(self, tool, session, turn_id) -> dict | None:
        if not isinstance(turn_id, str) or not turn_id:
            return None
        with self._locked():
            self._ensure()
            return _json(self._receipt_path(self._identity(tool, session)["writer_id"], turn_id))

    def _ack(self, identity: dict, packet_id: str) -> dict:
        state = _json(self._state_path(identity), {})
        if not state:
            raise ValueError("当前会话没有待确认的同步包")
        for task, item in state.get("tasks", {}).items():
            pending = item.get("pending")
            if pending and pending["packet_id"] == packet_id:
                if state.get("task") != task:
                    raise ValueError("同步包属于当前会话的另一任务；先切回任务或重新恢复")
                next_state = pending["next_state"]
                next_state["last_ack"] = packet_id
                next_state["last_ack_at"] = utc_now()
                state["tasks"][task] = next_state
                state["updated_at"] = utc_now()
                atomic_json(self._state_path(identity), state)
                return {"acknowledged": True, "packet_id": packet_id, "task": task}
            if item.get("last_ack") == packet_id:
                return {"acknowledged": True, "packet_id": packet_id, "task": task, "duplicate": True}
        raise ValueError("同步包不属于当前会话、已失效或不是当前待确认包")

    def ack(self, tool, session, packet_id):
        if not isinstance(packet_id, str) or not packet_id:
            raise ValueError("packet_id 不能为空")
        with self._locked():
            self._ensure()
            return self._ack(self._identity(tool, session), packet_id)

    def publish(self, tool, session, task, payload) -> dict:
        task = _identifier(task, "task")
        with self._locked():
            self._ensure()
            identity = self._identity(tool, session)
            events = self._events()
            payload = self._validate_payload(payload, events)
            state = self._state(identity, task)
            atomic_json(self._state_path(identity), state)
            ack_result = None
            if payload.get("ack_packet"):
                ack_result = self._ack(identity, payload["ack_packet"])
            turn_id = str(payload.get("turn_id") or "manual-" + uuid.uuid4().hex)
            prior = _json(self._receipt_path(identity["writer_id"], turn_id), {})
            event_ids = list(prior.get("event_ids", []))
            appended = []
            if not payload.get("noop"):
                for key in ("ack_packet", "noop"):
                    payload.pop(key, None)
                digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
                duplicate = next((event for event in events if event["writer_id"] == identity["writer_id"] and event.get("turn_id") == turn_id and event.get("payload_digest") == digest), None)
                if duplicate:
                    event = duplicate
                else:
                    previous = [event for event in events if event["writer_id"] == identity["writer_id"]]
                    seq = max((event["seq"] for event in previous), default=0) + 1
                    event = {**payload, "schema": SCHEMA, "event_id": f"{identity['writer_id']}#{seq:06d}", "seq": seq, "writer_id": identity["writer_id"], "tool": identity["tool"], "task": task, "turn_id": turn_id, "time": utc_now(), "payload_digest": digest}
                    stamp = datetime.now(timezone.utc).strftime("%Y-%m")
                    segment = (seq - 1) // 200 + 1
                    path = self.path("shared/events", identity["writer_id"], f"{stamp}-{segment:04d}.jsonl")
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with open(path, "a", encoding="utf-8", newline="\n") as stream:
                        stream.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
                        stream.flush()
                        os.fsync(stream.fileno())
                    events.append(event)
                    appended.append(event["event_id"])
                if event["event_id"] not in event_ids:
                    event_ids.append(event["event_id"])
                self._project_views(events)
            receipt = {"turn_id": turn_id, "published": bool(event_ids), "noop": not event_ids, "event_ids": event_ids, "time": utc_now(), "timestamp": utc_now(), "task": task, "writer_id": identity["writer_id"]}
            atomic_json(self._receipt_path(identity["writer_id"], turn_id), receipt)
            return {**receipt, "appended": appended, "ack": ack_result, "handoff_path": str(self.path("handoff", identity["writer_id"] + ".md")) if any(event.get("handoff") for event in events if event["writer_id"] == identity["writer_id"]) else None}

    def _recovery_items(self, events: list, task: str, project: dict, budget=2000) -> list:
        relevant = [event for event in events if self._relevant(event, task)]
        active = self._active(relevant)
        durable = [event for event in active if event.get("durable")]
        unresolved = [event for event in active if event.get("decision") == "proposed" or event.get("evidence") in ("failed", "uncertain")]
        cards = self._cards(events, task)
        newest_cards = sorted(cards.items(), key=lambda value: value[1]["event"]["time"], reverse=True)[:3]
        candidates = []
        for writer, card in newest_cards:
            preview = card["text"].splitlines()[0][:75]
            candidates.append({"key": "card:" + writer, "text": f"状态卡 {writer}：{preview}；全文 handoff/{writer}.md", "commit": {}, "category": "card"})
        selected = {}
        for event in durable[-3:] + unresolved[-2:] + relevant[-3:]:
            selected[event["event_id"]] = event
        for event in selected.values():
            # Recovery is a bounded navigation baseline, not a replay of all raw events.
            line = self._event_line(event)
            if len(line) > 130:
                line = line[:125] + "…（详见原始事件）"
            candidates.append({"key": event["event_id"], "text": line, "commit": {}, "category": "event"})
        header = f"项目：{str(project['name'])[:30]}；任务：{task}。恢复水位表示已交付当前视图及索引，不代表逐条阅读历史。"
        # Reserve enough room for exact omitted counts and a retrieval pointer.
        selected_items = []
        maximum = max(0, budget - 100)
        def footer(items):
            included = {item["key"] for item in items}
            read_cards = sum(item.get("category") == "card" for item in items)
            omitted_durable = sum(event["event_id"] not in included for event in durable)
            omitted_unresolved = sum(event["event_id"] not in included for event in unresolved)
            return f"未展开：卡片 {len(cards)-read_cards}，有效约束 {omitted_durable}，未决 {omitted_unresolved}；同任务历史卡未自动加载。索引 shared/current/{task}.md；按任务相关性查证，勿把索引视为已读证据。"
        for candidate in candidates:
            trial = selected_items + [candidate]
            text = "\n\n".join([header] + [item["text"] for item in trial] + [footer(trial)])
            if estimated_tokens(text) <= maximum:
                selected_items = trial
        text = "\n\n".join([header] + [item["text"] for item in selected_items] + [footer(selected_items)])
        if estimated_tokens(text) > maximum:
            # Tiny caller budgets still receive an honest index, not a secretly skipped history.
            text = f"任务 {task}；索引 shared/current/{task}.md。未展开 card={len(cards)}, durable={len(durable)}, unresolved={len(unresolved)}；历史未逐条读，按相关性检索。"
        if estimated_tokens(text) > maximum:
            raise ValueError("恢复预算不足以容纳任务索引；请使用默认2000或提高budget")
        return [{"key": "recovery-baseline", "text": text, "commit": {}}]

    @staticmethod
    def _source_line(event: dict) -> str:
        sources = event.get("sources", [])
        return "\n来源：" + "；".join(sources[:3]) + (f"；另{len(sources)-3}项见原始事件" if len(sources) > 3 else "") if sources else ""

    def sync(self, tool, session, task="T-START", mode="auto", budget=None) -> dict:
        task = _identifier(task, "task")
        if mode not in ("auto", "recover", "delta"):
            raise ValueError("mode 必须是 auto/recover/delta")
        with self._locked():
            project = self._ensure()
            identity = self._identity(tool, session)
            state = self._state(identity, task, recover=mode == "recover")
            item = state["tasks"].get(task, {})
            if not isinstance(item, dict):
                if mode != "recover":
                    raise ValueError("当前任务读取状态损坏；使用 recover 重建")
                item = {}
            if mode != "recover" and item.get("pending"):
                return self._public_packet(item["pending"], identity)
            events = self._events()
            if not self.path("shared/current", task + ".md").exists():
                self._project_views(events, (task,))
            continuing_recovery = bool(item.get("queue")) and item.get("queue_mode") == "recover"
            recover = mode == "recover" or (not item.get("initialized") and not continuing_recovery) or state.get("last_task") != task or item.get("protocol_version") != project.get("protocol_version")
            if recover:
                relevant = [event for event in events if self._relevant(event, task)]
                heads = {}
                for event in relevant:
                    heads[event["writer_id"]] = max(heads.get(event["writer_id"], 0), event["seq"])
                cards = self._cards(events, task)
                item = {"initialized": False, "generation": uuid.uuid4().hex[:12], "watermarks": {}, "card_hashes": {}, "protocol_version": project.get("protocol_version"), "queue": self._recovery_items(events, task, project, 2000 if budget is None else int(budget)), "offset": 0, "queue_mode": "recover", "target_watermarks": heads, "target_cards": {writer: hashlib.sha256(card["text"].encode()).hexdigest() for writer, card in cards.items()}}
            elif not item.get("queue"):
                relevant = [event for event in events if self._relevant(event, task) and event["seq"] > item.get("watermarks", {}).get(event["writer_id"], 0)]
                queue = [{"key": event["event_id"], "text": self._event_line(event) + self._source_line(event), "commit": {event["writer_id"]: event["seq"]}} for event in relevant]
                cards = self._cards(events, task)
                for writer, card in cards.items():
                    digest = hashlib.sha256(card["text"].encode()).hexdigest()
                    if item.get("card_hashes", {}).get(writer) != digest:
                        queue.append({"key": "card:" + writer, "text": f"变化状态卡 {writer}\n" + card["text"].rstrip(), "commit": {}, "card_hash": {writer: digest}})
                item["queue"] = queue
                item["offset"] = 0
                item["queue_mode"] = "delta"
            packet_mode = item.get("queue_mode", "delta")
            default_budget = 2000 if packet_mode == "recover" else 500
            budget = default_budget if budget is None else int(budget)
            if budget < 256 or budget > 16000:
                raise ValueError("budget 必须在256至16000之间（UTF-8字节保守token估算）")
            queue = copy.deepcopy(item.get("queue", []))
            if not queue:
                state["tasks"][task] = item
                state["last_task"] = task
                atomic_json(self._state_path(identity), state)
                return {"packet_id": None, "mode": "delta", "text": "", "has_more": False, "estimated_tokens": 0, "writer_id": identity["writer_id"], "task": task, "unchanged": True}
            packet_id = uuid.uuid4().hex
            header = f"同步 {packet_mode}｜{task}｜包 {packet_id[:8]}\n"
            next_state = copy.deepcopy(item)
            next_state.pop("pending", None)
            offset = int(item.get("offset", 0))
            body = []
            used = estimated_tokens(header)
            while queue:
                current = queue[0]
                remaining = current["text"][offset:]
                available = budget - used - 2
                if available < 16:
                    break
                if estimated_tokens(remaining) <= available:
                    body.append(remaining)
                    used += estimated_tokens(remaining) + 2
                    for writer, seq in current.get("commit", {}).items():
                        next_state.setdefault("watermarks", {})[writer] = max(next_state.get("watermarks", {}).get(writer, 0), seq)
                    next_state.setdefault("card_hashes", {}).update(current.get("card_hash", {}))
                    queue.pop(0)
                    offset = 0
                else:
                    # Split at Unicode boundaries, retaining offset until the whole item is acknowledged.
                    prefix = "续条：" if offset else ""
                    available -= estimated_tokens(prefix)
                    count, size = 0, 0
                    for character in remaining:
                        width = len(character.encode("utf-8"))
                        if size + width > available:
                            break
                        size += width
                        count += 1
                    if count:
                        body.append(prefix + remaining[:count])
                        offset += count
                    break
            text = header + "\n\n".join(body)
            next_state["queue"] = queue
            next_state["offset"] = offset
            has_more = bool(queue)
            if not has_more:
                if packet_mode == "recover":
                    next_state["watermarks"] = next_state.pop("target_watermarks", {})
                    next_state["card_hashes"] = next_state.pop("target_cards", {})
                next_state["initialized"] = True
                next_state["queue_mode"] = "delta"
                next_state["offset"] = 0
            packet = {"packet_id": packet_id, "mode": packet_mode, "task": task, "text": text, "has_more": has_more, "estimated_tokens": estimated_tokens(text), "estimator": "utf8_bytes_upper_bound", "next_state": next_state, "created_at": utc_now()}
            item["pending"] = packet
            state["tasks"][task] = item
            state["last_task"] = task
            state["updated_at"] = utc_now()
            atomic_json(self._state_path(identity), state)
            return self._public_packet(packet, identity)

    @staticmethod
    def _public_packet(packet: dict, identity: dict) -> dict:
        return {key: value for key, value in packet.items() if key != "next_state"} | {"writer_id": identity["writer_id"]}

    def status(self) -> dict:
        with self._locked():
            project = self._ensure()
            events = self._events()
            return {"project": project, "root": str(self.root), "event_count": len(events), "writers": sorted({event["writer_id"] for event in events}), "tasks": sorted({event["task"] for event in events}), "note": "配置/文件存在不代表四个桌面客户端已完成真实接入验收"}

    def doctor(self) -> dict:
        with self._locked():
            project = self._ensure()
            events = self._events()
            self._project_views(events)
            errors = []
            for writer, card in self._cards(events).items():
                if len(card["text"].splitlines()) > 12:
                    errors.append(f"状态卡超过12行：{writer}")
            return {"ok": not errors, "project_id": project["project_id"], "event_count": len(events), "errors": errors, "views_rebuilt": True, "estimator": "utf8_bytes_upper_bound", "note": "本检查验证本地记录结构；不代表原生客户端生命周期hooks已触发"}
