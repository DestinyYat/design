"""Project-scoped lifecycle adapters. No model calls and no implicit read ack.

Read a native hook JSON object on stdin; write only the native JSON response on
stdout. The configured --root is authoritative, never the hook's working dir.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import uuid


def _core():
    try:
        from .core import Store, atomic_json, file_lock, utc_now
    except ImportError:
        from core import Store, atomic_json, file_lock, utc_now
    return Store, atomic_json, file_lock, utc_now


def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open(encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("hook state must be a JSON object")
    return value


def _native_response(event: str, text: str) -> dict:
    if not text:
        return {}
    return {"hookSpecificOutput": {"hookEventName": event,
                                   "additionalContext": text}}


def _quote_ps(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _receipt_instruction(root: Path, tool: str, session: str, task: str,
                         turn: str, packet: str | None = None) -> str:
    command = (f"& {_quote_ps(sys.executable)} {_quote_ps(str(root / 'tools/coop/coop.py'))} "
               f"--root {_quote_ps(str(root))} receipt --tool {tool} "
               f"--session {_quote_ps(session)} --task {_quote_ps(task)} "
               f"--turn {_quote_ps(turn)} --noop")
    if packet:
        command += " --ack " + _quote_ps(packet)
    return ("仅在本轮没有需留存的新进展时执行以下 PowerShell 命令：\n" + command
            + "\n有新进展则用 publish --input JSON文件；payload 必须包含 turn_id="
            + json.dumps(turn, ensure_ascii=False)
            + (" 及 ack_packet=" + json.dumps(packet) if packet else "")
            + "。不得为了通过检查把有进展的轮次标为 noop。")


def _sync_footer(tool: str, session: str, task: str, turn: str,
                 packet: str | None, more: bool, meta: str | None = None) -> str:
    """All dynamic metadata counts against the hook's context budget."""
    if meta:
        return (f"\nCOOP meta={meta}"
                + (f" packet={packet}" if packet else " unchanged=1")
                + (" more=1" if more else "")
                + "; full IDs in meta (not injected); read->ack; end->publish/receipt."
                + " shared/protocol.md.")
    return (f"\nCOOP tool={tool} sid={session} task={task} turn={turn}"
            + (f" packet={packet}" if packet else " unchanged=1")
            + (" more=1" if more else "")
            + "; read->ack; end->publish/receipt(noop only if unchanged)."
            + " See shared/protocol.md.")


def _choose_budget(tool: str, session: str, task: str, turn: str,
                   writer: str, limit: int) -> tuple[int, str | None]:
    """Reserve the exact worst-case footer before Store prepares a packet."""
    footer = _sync_footer(tool, session, task, turn, "p" * 32, True)
    meta = None
    if limit - len(footer.encode("utf-8")) < 256:
        meta = f".coop/hook-meta/{writer}.json"
        footer = _sync_footer(tool, session, task, turn, "p" * 32, True, meta)
    budget = limit - len(footer.encode("utf-8"))
    if budget < 256:
        # Writer ids are bounded by Store; this is a visible contract failure,
        # not permission to silently overrun the requested context budget.
        raise ValueError("hook metadata cannot fit budget; use explicit recovery")
    return budget, meta


def handle_event(store, tool: str, data: dict, *, task: str | None = None) -> dict:
    """Use a Store-compatible object; injectable for stdio/contract tests."""
    _, atomic_json, file_lock, utc_now = _core()
    if not isinstance(data, dict):
        raise ValueError("hook input must be a JSON object")
    session = data.get("session_id") or data.get("conversation_id")
    if not isinstance(session, str) or not session.strip():
        raise ValueError("native session_id is required; no shared fallback session is used")
    session = session.strip()
    event = str(data.get("hook_event_name", ""))
    if event not in {"SessionStart", "UserPromptSubmit", "Stop", "PostCompact"}:
        return {}
    root = Path(store.root).resolve()
    # register(None) must preserve an existing task; current_task is preferred.
    if task is None and hasattr(store, "current_task"):
        task = store.current_task(tool, session)
    registration = store.register(tool, session, task or "T-START")
    task = task or registration.get("task", "T-START")
    writer = registration["writer_id"]
    if Path(writer).name != writer or any(x in writer for x in ("/", "\\", ":")):
        raise ValueError("invalid writer identity")
    state_path = root / ".coop" / "hook-state" / (writer + ".json")
    with file_lock(state_path.with_suffix(".lock")):
        state = _load(state_path)
        fresh = not bool(state)
        source = str(data.get("source", ""))
        if event == "SessionStart" and source not in {"compact", "clear", "fork"}:
            startup_text = (
                "本项目遵循根 AGENTS.md 与 shared/protocol.md。首条用户消息前将读取限额恢复包；"
                "无需通读所有会话、原始事件或成果。若未收到后续同步包，主动调用 coop sync。")
            state.update(needs_recover=True, last_event=event, task=task,
                         startup_context_bytes=len(startup_text.encode("utf-8")),
                         time=utc_now())
            atomic_json(state_path, state)
            return _native_response(event, startup_text)

        if event in {"SessionStart", "PostCompact", "UserPromptSubmit"}:
            native_turn = data.get("turn_id") or data.get("query_id")
            if event == "UserPromptSubmit":
                # TRAE does not document a query id: preserve the generated id
                # until Stop, rather than inferring identity from prompt text.
                turn = str(native_turn) if native_turn else "local-" + uuid.uuid4().hex
                if state.get("turn_id") != turn:
                    state.pop("stop_reminded", None)
                    state.pop("publication_missing", None)
                state["turn_id"] = turn
            else:
                turn = str(native_turn or state.get("turn_id") or "restore-" + uuid.uuid4().hex)
                state["turn_id"] = turn
            force = event != "UserPromptSubmit" or state.get("needs_recover", fresh)
            limit = 2000 if force else 500
            if force and event == "UserPromptSubmit":
                # Startup and the first prompt can both enter one model request.
                # Count the already emitted startup note in that initial budget.
                limit -= int(state.pop("startup_context_bytes", 0))
            core_budget, meta = _choose_budget(tool, session, task, turn, writer, limit)
            packet = store.sync(tool, session, task, mode="recover" if force else "auto",
                                budget=core_budget)
            packet_id = packet.get("packet_id")
            # Store retains pending packets until explicit acknowledgement.
            state.update(needs_recover=False, task=task, last_event=event,
                         packet_id=packet_id, time=utc_now())
            atomic_json(state_path, state)
            text = str(packet.get("text", ""))
            footer = _sync_footer(tool, session, task, turn, packet_id,
                                  bool(packet.get("has_more")), meta)
            metadata = {"tool": tool, "session": session, "task": task,
                        "turn_id": turn, "packet_id": packet_id,
                        "has_more": bool(packet.get("has_more")),
                        "root": str(root), "hook_context_limit": limit,
                        "core_packet_budget": core_budget,
                        "packet_body_delivered": True,
                        "note": "Metadata is an operational index, not a read acknowledgement."}
            # An existing pending packet can have been created by a manual CLI
            # with a larger budget. Never truncate it and mark it delivered.
            if len((text + footer).encode("utf-8")) > limit:
                meta = f".coop/hook-meta/{writer}.json"
                pending_path = f".coop/hook-packets/{writer}/{packet_id}.json"
                atomic_json(root / pending_path, packet)
                metadata.update(packet_body_delivered=False, pending_file=pending_path,
                                pending_estimated_tokens=len(text.encode("utf-8")))
                text = ("COOP budget index: pending body NOT injected; cursor NOT advanced. "
                        f"meta={meta}. Read this session's meta or explicitly recover "
                        "with a smaller budget; do not ack the unseen body.")
                if len(text.encode("utf-8")) > limit:
                    raise ValueError("hook budget index cannot fit requested limit")
                atomic_json(root / meta, metadata)
                return _native_response(event, text)
            if meta:
                atomic_json(root / meta, metadata)
            text += footer
            return _native_response(event, text)

        turn = str(data.get("turn_id") or data.get("query_id") or state.get("turn_id") or "")
        if not turn:
            return {"systemMessage": "协作收尾检查缺少轮次标识；请主动发布或登记无进展收据。"}
        receipt = store.get_receipt(tool, session, turn)
        if receipt:
            state.update(publication_missing=False, last_event=event, time=utc_now())
            atomic_json(state_path, state)
            return {}
        if (state.get("stop_reminded") == turn or data.get("stop_hook_active")
                or int(data.get("loop_count", 0) or 0) >= 1):
            state.update(publication_missing=True, last_event=event, time=utc_now())
            atomic_json(state_path, state)
            return {"systemMessage": "协作记录仍缺本轮收据；已停止重复催写，磁盘交接尚未确认完整。"}
        state.update(stop_reminded=turn, publication_missing=True,
                     last_event=event, time=utc_now())
        atomic_json(state_path, state)
        return {"decision": "block", "reason":
                "本轮尚未留下协作记录收据。请先把关键进展与理由通过 publish 保存，"
                "或在确实无新进展时登记 noop；完成后结束，无需再征求用户许可。\n"
                + _receipt_instruction(root, tool, session, task, turn,
                                       state.get("packet_id"))}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tool", required=True, choices=("codex", "trae", "workbuddy", "deepseekharness"))
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--task")
    args = parser.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
    try:
        raw = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8-sig")
        data = json.loads(raw)
        Store, _, _, _ = _core()
        root = args.root.resolve()
        if not (root / "shared/project.json").is_file():
            raise ValueError("project is not initialized: shared/project.json missing")
        store = Store(root)
        response = handle_event(store, args.tool, data, task=args.task)
        print(json.dumps(response, ensure_ascii=False))
        return 0
    except Exception as exc:
        # Native runtimes can ignore nonzero hook failures. Also emit a visible
        # warning, without pretending that collaboration state was loaded.
        message = "协作同步/收尾失败，未声称已完成：" + str(exc)
        print(json.dumps({"systemMessage": message}, ensure_ascii=False))
        print(message, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
