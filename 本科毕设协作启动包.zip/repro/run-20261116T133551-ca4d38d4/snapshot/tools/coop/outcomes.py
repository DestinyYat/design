"""Evidence-bound candidates; approval records refer to an actual user instruction."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import uuid

from core import Store, atomic_json, atomic_text, file_lock


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def _safe_id(value):
    if not value or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in value):
        raise ValueError("候选标识只能使用字母、数字、连字符和下划线")
    return value


def _has_source(store, reference):
    if reference.startswith(("https://", "http://")):
        return True  # Recorded provenance, not a network verification claim.
    if "#" in reference:
        event_id = reference.rsplit("#", 1)[-1]
        if any(e.get("event_id") in {reference, event_id} for e in store.events()):
            return True
    if any(e.get("event_id") == reference for e in store.events()):
        return True
    path = Path(reference)
    if path.is_absolute():
        return False
    resolved = (store.root / path).resolve()
    try:
        resolved.relative_to(store.root.resolve())
    except ValueError:
        return False
    return resolved.exists()


def create_candidate(store: Store, tool, session, task, data):
    title, body, sources = data.get("title", "").strip(), data.get("body", "").strip(), data.get("sources", [])
    if not title or not body or not sources or not isinstance(sources, list):
        raise ValueError("候选必须提供 title、body、sources数组")
    missing = [s for s in sources if not isinstance(s, str) or not _has_source(store, s)]
    if missing:
        raise ValueError(f"候选来源不存在或不是项目相对路径/事件编号/URL: {missing}")
    identifier = _safe_id(data.get("id") or "candidate-" + uuid.uuid4().hex[:12])
    folder = store.root / "outcomes" / "candidates"
    folder.mkdir(parents=True, exist_ok=True)
    record = {"schema_version": 1, "id": identifier, "task": task, "title": title, "body": body,
              "sources": sources, "created_at": timestamp(), "status": "pending",
              "writer_id": store.register(tool, session, task)["writer_id"],
              "kind": data.get("kind", "design"), "evidence": data.get("evidence", "unverified")}
    if record["kind"] not in {"progress", "reproduction", "design"}:
        raise ValueError("kind 应为 progress、reproduction 或 design")
    with file_lock(store.root / ".coop" / "locks" / "outcomes.lock"):
        if (folder / (identifier + ".json")).exists():
            raise ValueError("同名候选已存在；请建立新候选并引用旧版本")
        atomic_json(folder / (identifier + ".json"), record)
        _render(folder / (identifier + ".md"), record)
    event = store.publish(tool, session, task, {"kind": "candidate", "summary": f"起草成果候选 {identifier}：{title}"[:130],
                          "why": "由原始记录和证据形成待用户裁决的叙事。", "decision": "proposed",
                          "sources": [f"outcomes/candidates/{identifier}.md"] + sources})
    return {"id": identifier, "status": "pending", "path": str(folder / (identifier + ".md")), "publication": event}


def _render(path, record):
    lines = [record["title"], "状态：" + record["status"], "任务：" + record["task"],
             "类别：" + record["kind"], "证据状态：" + record["evidence"], "", record["body"], "", "来源："]
    lines.extend("- " + s for s in record["sources"])
    if record.get("user_decision"):
        lines.extend(["", "用户裁决来源：" + record["user_decision"]["source"],
                      "裁决理由：" + record["user_decision"]["reason"]])
    atomic_text(path, "\n".join(lines) + "\n")


def decide_candidate(store, tool, session, task, candidate, decision, reason, source):
    _safe_id(candidate)
    if decision not in {"accept", "reject"} or not reason.strip() or not source.strip():
        raise ValueError("必须提供真实用户裁决、理由和可定位的用户指令来源")
    folder = store.root / "outcomes" / "candidates"
    with file_lock(store.root / ".coop" / "locks" / "outcomes.lock"):
        metadata = folder / (candidate + ".json")
        record = json.loads(metadata.read_text(encoding="utf-8"))
        if record["task"] != task:
            raise ValueError("候选属于另一任务，请使用其真实 task")
        if record["status"] != "pending":
            raise ValueError("此候选已有裁决；修正应创建新候选，不能覆盖历史")
        event = store.publish(tool, session, task, {"kind": "user_decision", "summary": f"用户{ '采纳' if decision == 'accept' else '否决'}候选 {candidate}。",
                              "why": reason, "decision": "adopted" if decision == "accept" else "rejected",
                              "authority": "user", "authority_source": source,
                              "sources": [f"outcomes/candidates/{candidate}.md", source]})
        record["status"] = "accepted" if decision == "accept" else "rejected"
        record["user_decision"] = {"decision": decision, "reason": reason, "source": source,
                                    "time": timestamp(), "publication": event}
        atomic_json(metadata, record)
        _render(folder / (candidate + ".md"), record)
        if decision == "accept":
            accepted = store.root / "outcomes" / "accepted" / record["kind"]
            accepted.mkdir(parents=True, exist_ok=True)
            _render(accepted / (candidate + ".md"), record)
    return {"id": candidate, "status": record["status"], "publication": event,
            "authority_note": "本操作仅记录调用者提供的用户裁决；程序不能独立证明对话中确有该授权。"}
