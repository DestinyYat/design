"""Capture an execution before launch. Python 3.10, standard library only."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone

from core import Store, atomic_json, file_lock


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


EXCLUDED = {".git", ".coop", "__pycache__", "node_modules", ".venv", "backups", "repro"}


def capture(root, destination, entries):
    """Explicit inputs only. Never silently omit an explicitly named input."""
    captured = []
    seen = set()
    for entry in entries:
        source = Path(entry).expanduser()
        source = (root / source).resolve() if not source.is_absolute() else source.resolve()
        if not source.exists():
            raise ValueError(f"采集对象不存在: {source}")
        paths = sorted(source.rglob("*")) if source.is_dir() else [source]
        for item in paths:
            if not item.is_file():
                continue
            relative_source = item.relative_to(source) if source.is_dir() else Path(item.name)
            if any(part in EXCLUDED for part in relative_source.parts):
                continue
            if item.is_symlink():
                raise ValueError(f"请显式采集符号链接的实际输入: {item}")
            key = str(item.resolve()).casefold()
            if key in seen:
                continue
            seen.add(key)
            try:
                relative = item.resolve().relative_to(root)
            except ValueError:
                relative = Path("external") / hashlib.sha256(str(source).encode()).hexdigest()[:10] / relative_source
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            before = digest(item)
            shutil.copy2(item, target)
            after = digest(item)
            if before != after or before != digest(target):
                raise ValueError(f"采集时文件变化，请固定输入后重试: {item}")
            captured.append({"source": str(item), "snapshot": str(relative).replace("\\", "/"),
                             "sha256": before, "size": item.stat().st_size})
    return captured


def git_info(cwd):
    result = {}
    for key, argv in (("commit", ["git", "rev-parse", "HEAD"]),
                      ("status", ["git", "status", "--porcelain=v1"]),
                      ("diff", ["git", "diff", "--binary", "HEAD"])):
        try:
            p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15)
            if p.returncode == 0:
                result[key] = p.stdout
        except (OSError, subprocess.TimeoutExpired):
            pass
    return result


def run_recorded(store: Store, tool, session, task, argv, cwd=None, inputs=(), captures=(),
                 label="运行", allow_no_inputs=False):
    if not argv:
        raise ValueError("run 需要 -- 后的实际命令")
    if not inputs and not captures and not allow_no_inputs:
        raise ValueError("请用 --capture 保存运行代码、--input 保存输入；纯无输入探针可显式使用 --allow-no-inputs")
    root = store.root.resolve()
    store.ensure_initialized()
    identity = store.register(tool, session, task)
    run_id = "run-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    run_dir = root / "repro" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    working = Path(cwd).resolve() if cwd else root
    if not working.is_dir():
        raise ValueError(f"工作目录不存在: {working}")
    manifest = {"schema_version": 1, "run_id": run_id, "task": task, "label": label,
                "writer_id": identity["writer_id"], "created_at": now(), "status": "preparing",
                "argv": list(argv), "cwd": str(working), "supervisor_pid": os.getpid(),
                "environment": {"platform": platform.platform(), "python": sys.version,
                                "python_executable": sys.executable},
                "declared_inputs": list(map(str, inputs)), "declared_code": list(map(str, captures)),
                "evidence_state": "unverified",
                "limitations": ["快照只覆盖显式声明的文件；未声明依赖、外部服务和硬件条件需另行补充。",
                                "命令在原工作目录执行；快照留证不会自动隔离并发修改。运行期间应保持代码和输入不变。"]}
    atomic_json(run_dir / "manifest.json", manifest)
    try:
        manifest["files"] = capture(root, run_dir / "snapshot", list(captures) + list(inputs))
        repository = git_info(working)
        if repository.get("diff"):
            (run_dir / "working-tree.patch").write_text(repository.pop("diff"), encoding="utf-8")
        manifest["git"] = repository
        manifest.update(status="prepared", prepared_at=now())
        atomic_json(run_dir / "manifest.json", manifest)
        (run_dir / "COMMAND.md").write_text(
            "实际命令参数（JSON数组，重放时按数组执行，不进行shell拼接）：\n" +
            json.dumps(list(argv), ensure_ascii=False) + "\n工作目录：" + str(working) +
            "\n输入和代码见 snapshot/ 与 manifest.json；原始路径失效时需先恢复快照并核对依赖。\n", encoding="utf-8")
        store.publish(tool, session, task, {"kind": "run", "summary": f"启动运行 {run_id}：{label}"[:110],
                      "why": "在执行前保存实际命令、显式输入与代码快照。", "evidence": "unverified",
                      "sources": [f"repro/{run_id}/manifest.json"]})
        with (run_dir / "stdout.log").open("wb") as out, (run_dir / "stderr.log").open("wb") as err:
            process = subprocess.Popen(list(argv), cwd=working, stdout=out, stderr=err, shell=False)
            manifest.update(status="running", started_at=now(), pid=process.pid)
            atomic_json(run_dir / "manifest.json", manifest)
            code = process.wait()
        manifest.update(status="completed" if code == 0 else "failed", returncode=code, finished_at=now())
        changed = []
        for item in manifest["files"]:
            source = Path(item["source"])
            if not source.is_file() or digest(source) != item["sha256"]:
                changed.append(item["source"])
        manifest["changed_sources_during_run"] = changed
        if changed:
            manifest["limitations"].append("执行期间声明文件发生变化，本次运行与启动快照可能不一致，复现受限。")
        manifest["outputs"] = {name: {"sha256": digest(run_dir / name), "size": (run_dir / name).stat().st_size}
                               for name in ("stdout.log", "stderr.log")}
        atomic_json(run_dir / "manifest.json", manifest)
        (run_dir / "SUMMARY.md").write_text(
            f"运行：{run_id}\n状态：{manifest['status']}；退出码：{code}\n"
            "实验结论：尚未解释；退出码不等于方案验证成功。\n证据：manifest.json、stdout.log、stderr.log、snapshot/。\n" +
            ("注意：运行期间输入或代码变化，需核实。\n" if changed else ""), encoding="utf-8")
        store.publish(tool, session, task, {"kind": "run", "summary": f"运行 {run_id} 已结束，退出码 {code}。",
                      "why": "保存原始输出；实验结论由后续分析给出。", "evidence": "unverified",
                      "sources": [f"repro/{run_id}/SUMMARY.md", f"repro/{run_id}/manifest.json"]})
        return {"run_id": run_id, "status": manifest["status"], "returncode": code,
                "directory": str(run_dir), "changed_sources": changed}
    except BaseException as exc:
        manifest.update(status="supervision_interrupted" if isinstance(exc, KeyboardInterrupt) else "capture_or_execution_error",
                        error=f"{type(exc).__name__}: {exc}", last_update=now())
        if manifest.get("pid"):
            manifest["limitations"].append("监督程序中断不证明子进程停止；重开会话先核实进程和输出，不自动重跑。")
        atomic_json(run_dir / "manifest.json", manifest)
        raise
