本科毕设初始基线，2026-11-16。

项目根目录：C:\Users\myby\Desktop\codex\design。
用户已授权在此目录建立四工具协作机制，并要求一份可交给任意 agent 执行的实施任务书。
首次检查该目录为空；目前只建立协作设施，没有迁入旧聊天或其他项目代码。
毕设背景资料在 C:\Users\myby\Desktop\codex\毕业信息；本次未读取。
研究题目、技术方向、实验数据和研究进度尚未登记，不从协作程序测试推断。
当前设施任务为 T-START。后续由用户的正常对话确定实际研究任务及材料读取范围。
日常入口：AGENTS.md；操作：shared/QUICKSTART.md；维护任务书：shared/IMPLEMENTATION.md。
安装与实测状态以 shared/SETUP_REPORT.md 为准。机械测试不代表四个客户端都真实触发过。
