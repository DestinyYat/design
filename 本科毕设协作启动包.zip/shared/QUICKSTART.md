# 日常入口

项目根目录：`C:\Users\myby\Desktop\codex\design`。先遵循 `shared/protocol.md`。
在项目根目录执行；`SESSION` 使用当前原生会话 ID，`TASK` 使用用户当前任务标识，初始为 `T-START`。
工具标识：`codex`、`trae`、`workbuddy`、`deepseekharness`。同一会话恢复保持 ID，新会话换 ID。

```powershell
python tools/coop/coop.py status
python tools/coop/coop.py session --tool codex --task T-START
python tools/coop/coop.py sync --tool codex --session SESSION --task TASK --mode auto
python tools/coop/coop.py ack --tool codex --session SESSION --packet PACKET
python tools/coop/coop.py publish --tool codex --session SESSION --task TASK --turn TURN --input .coop/publish.json
python tools/coop/coop.py receipt --tool codex --session SESSION --task TASK --turn TURN --noop
python tools/coop/coop.py doctor
```

无 hook 时只生成一次 `SESSION` 并在本会话复用；每轮换一个 `TURN`。读完同步包再确认 `PACKET`；上下文不可靠时把 `auto` 换为 `recover`。
若 hook 只给 `meta=...`，只读指定索引；`packet_body_delivered=false` 时按 `core_packet_budget` 恢复或完整读 `pending_file`，不得确认未见正文。
增量有后续页时继续分页；恢复包超量历史只给计数与索引，按需追查，不把全部旧对话分页读完。
`publish.json` 是 agent 当轮写的 UTF-8 输入，字段：`kind`、`summary`、`why`、`impact`、`sources`、`decision`、`evidence`、`durable`、`supersedes`、`handoff`、`turn_id`、`ack_packet`；按实际需要填写。`adopted` 还必须有 `authority: user` 和真实 `authority_source`。
`noop/durable` 用 JSON 布尔值；决策或方向、失败等记录必须 `why`，单纯事实不编理由；卡片最多12行，首行“接收者；动作”。
实验用 `run --help`，成果候选用 `candidate --help`，用户裁决收录用 `decide --help`，备份用 `backup --help`。
默认只读当前任务及增量；不要打开全部卡片、全部事件或整份实施任务书。
同步预算仅含同步数据和正常 hook 注入；短协议初次另读，用户对话、论文与工具输出不在此预算内。
客户端自动接入状态以验收报告和实际新会话验证为准；配置文件存在不代表已经自动运行。
