本科毕设协作设施安装与验收记录

日期：2026-11-16（Asia/Shanghai）。项目：C:\Users\myby\Desktop\codex\design。
项目 ID：b7e55efb-d1ce-4e11-83b7-86c2b6ddcbe5。初始任务：T-START。

已实际建立

- 可交给任意 agent 执行的实施与维护任务书：shared/IMPLEMENTATION.md。
- 日常入口：AGENTS.md、START_HERE.md、shared/protocol.md、shared/QUICKSTART.md。
- Python 标准库公共程序：tools/coop/coop.py、core.py、runs.py、outcomes.py、hooks.py。
- 按会话独立写入的原始事件、可重建阅读视图、会话专属游标、显式确认与无变化收据。
- Codex/TRAE 项目 hook 配置，TRAE/WorkBuddy 规则，WorkBuddy /coop 操作入口，DSH 接入状态说明。
- 运行前代码与输入快照、实际命令与环境、原始输出；有来源的成果候选和用户裁决收录；校验备份操作。
- 本次只建立协作设施。毕业信息目录未读取，未推测研究题目、方向、数据或研究完成度。

实际验证

完整验收通过 51 项测试：核心 28 项、hook 15 项、运行/成果/备份/跨工具 CLI 集成 8 项。
命令：D:\E-CLASS_APP\py310\python.exe -m unittest discover -s tests -v。
运行目录：C:\Users\myby\Desktop\codex\design。
运行标识：run-20261116T133551-ca4d38d4；退出码 0；测试耗时 52.329 秒。
证据：repro/run-20261116T133551-ca4d38d4/manifest.json、stderr.log、stdout.log、SUMMARY.md、snapshot/。
实际通过公共 run 操作启动验收：命令、代码、测试及 hook 配置在启动前采集；检测到运行前后源文件变化为 0。
测试中的方向、假设、实验和用户裁决均为临时项目夹具，没有当作毕设真实结论写入正式成果。

测试覆盖

- 四进程并发发布不丢失，原始编号唯一，重试幂等，卡片 12 行及首行动作校验。
- 读取确认隔离，未确认重放，长增量完整分页，任务切换和损坏游标恢复。
- 百历史会话和百长期条目不会扩大默认恢复总量；未展开记录给出计数和索引。
- 旧坑可追查、全局约束随任务接续、替代记录保留原始历史、旧投影页标失效。
- 正常 hook 注入连元数据按保守 UTF-8 字节估算控制在恢复 2000、增量 500；长身份和大 pending 包不假装已交付。
- hook 显式根路径、会话和轮次隔离、收尾最多提醒一次，以及真实 Windows shell 执行配置中的命令。
- 四工具 CLI 模拟接续、回原会话读增量；该测试没有调用四客户端中的模型。
- 失败运行留证、声明输入变化检测、候选来源检查与裁决、备份 ZIP 与逐文件哈希校验。

四客户端状态

Codex：.codex/hooks.json 已部署；本地机械链通过。探测到 npm CLI 为 0.133.0，临时使用 xhigh 参数确认 hooks=true。
该 CLI 默认读取用户全局的 ultra 会报不兼容；本次未修改全局模型/推理设置。桌面客户端与此 CLI 不应混为一个版本。
尚未在新的 Codex 项目会话中验证客户端实际加载配置、目录信任和完整模型轮次。

TRAE：.trae/hooks.json 和始终生效的 .trae/rules/coop.md 已部署；标准输入输出机械测试通过。
本机注册的 TraeWork CN 为 0.2.2。实际常用客户端是否信任目录、启用并加载这些 hook，需在本项目真实会话确认。

WorkBuddy：本机版本 5.9.3；.codebuddy/rules/coop.md 和 .codebuddy/commands/coop.md 已建立。
当前为规则驱动的公共程序接入，没有启用未经验证的桌面生命周期 hook。必须将本任务绑定到同一个物理项目目录。

DeepSeek Harness：本机版本 0.2.1-rc.5；根 AGENTS.md 提供规则入口，使用 tool=deepseekharness。
未启用未经本机验证的原生插件；后续步骤见 .dsh/COOP_ADAPTER_STATUS.md。规则驱动不等于生命周期强制触发。

正常使用与下一步

在任一工具打开 design 目录并新建本项目会话，发送：读取 AGENTS.md，接上毕设当前任务，并按我的下一条要求开始工作。
第一次具体研究任务由用户正常对话给出；agent 读必要材料后创建任务标识，不能把 T-START 设施验证当研究进展。
首次接入按实际客户端要求启用/信任项目规则或 hook；随后真实完成 TRAE → WorkBuddy → Codex → 旧会话增量 → 新会话恢复 → DSH 接续。
完成真实客户端验证时，追加新的验证事件并更新本报告，保留本次机械验收来源。

实际边界

2000/500 是同步数据及正常 hook 注入的保守估算限额，不包含用户对话、论文正文、代码阅读和其他工具输出。
恢复水位代表当前视图和来源索引已交付，不代表逐条读过所有历史；相关动作前仍需沿指针核实旧坑和原始证据。
公共 run 只采集显式声明文件，在原工作目录执行，并未隔离并发修改或保存全部外部依赖；有变化或缺依赖须报告复现受限。
候选裁决参数要求用户来源，但程序不能独立证明对话确有该授权；不得用参数伪造用户采纳。
代码编辑仍需遵守任务范围并避免同文件并行修改；本次没有安装拦截所有外部编辑器的强制代码锁。
原始 JSONL 不完整末行会显式报错并保留文件，不会跳过损坏记录伪称正常；修复前应保留备份。
本次没有执行真实毕设实验，没有调用四客户端模型做端到端验收，也没有修改它们的用户级配置。

详细审计

根实施操作：C:\Users\myby\Desktop\codex\audit\design\coop-setup-20261116-211354\command.md。
公开技术依据：C:\Users\myby\Desktop\codex\audit\design\coop-setup-20261116-211354\thought.md。
并行核心、适配和文档任务各自审计位于同一 audit/design 下的独立会话目录。
审计记录工具层实际操作和可核查结果，不声称覆盖全部底层操作系统事件。
